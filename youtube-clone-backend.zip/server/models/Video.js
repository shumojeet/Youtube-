const mongoose = require('mongoose');

const VideoSchema = new mongoose.Schema({
  videoId: String,
  title: String,
  thumbnailUrl: String,
  description: String,
  channelId: String,
  uploader: String,
  views: Number,
  likes: Number,
  dislikes: Number,
  uploadDate: String,
  category: String,
  comments: [String],
});

module.exports = mongoose.model('Video', VideoSchema);

const mongoose = require('mongoose');

const ChannelSchema = new mongoose.Schema({
  channelId: String,
  channelName: String,
  owner: String,
  description: String,
  channelBanner: String,
  subscribers: Number,
  videos: [String]
});

module.exports = mongoose.model('Channel', ChannelSchema);

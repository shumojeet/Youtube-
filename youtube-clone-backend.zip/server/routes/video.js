const express = require('express');
const Video = require('../models/Video');
const router = express.Router();

router.get('/', async (req, res) => {
  const videos = await Video.find();
  res.json(videos);
});

router.get('/:id', async (req, res) => {
  const video = await Video.findOne({ videoId: req.params.id });
  res.json(video);
});

router.post('/', async (req, res) => {
  const newVideo = new Video(req.body);
  await newVideo.save();
  res.status(201).json(newVideo);
});

router.put('/:id', async (req, res) => {
  const updated = await Video.findOneAndUpdate(
    { videoId: req.params.id },
    req.body,
    { new: true }
  );
  res.json(updated);
});

router.delete('/:id', async (req, res) => {
  await Video.findOneAndDelete({ videoId: req.params.id });
  res.json({ message: 'Deleted' });
});

module.exports = router;

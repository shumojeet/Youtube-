const express = require('express');
const Comment = require('../models/Comment');
const router = express.Router();

router.get('/:videoId', async (req, res) => {
  const comments = await Comment.find({ videoId: req.params.videoId });
  res.json(comments);
});

router.post('/', async (req, res) => {
  const newComment = new Comment(req.body);
  await newComment.save();
  res.status(201).json(newComment);
});

router.put('/:id', async (req, res) => {
  const updated = await Comment.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

router.delete('/:id', async (req, res) => {
  await Comment.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function Home() {
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    axios.get('/api/videos').then(res => setVideos(res.data));
  }, []);

  return (
    <div>
      <h1>YouTube Clone</h1>
      <div className='grid'>
        {videos.map(video => (
          <Link key={video.videoId} to={`/video/${video.videoId}`} className='video-card'>
            <img src={video.thumbnailUrl} alt={video.title} />
            <h3>{video.title}</h3>
            <p>{video.channelId} • {video.views} views</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default Home;
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Register() {
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleRegister = async () => {
    await axios.post('/api/auth/register', form);
    navigate('/login');
  };

  return (
    <div>
      <h2>Register</h2>
      <input name='username' placeholder='Username' onChange={handleChange} />
      <input name='email' placeholder='Email' onChange={handleChange} />
      <input name='password' type='password' placeholder='Password' onChange={handleChange} />
      <button onClick={handleRegister}>Register</button>
    </div>
  );
}

export default Register;
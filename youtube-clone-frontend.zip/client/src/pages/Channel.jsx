import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function Channel() {
  const { id } = useParams();
  const [channel, setChannel] = useState(null);

  useEffect(() => {
    axios.get(`/api/channels/${id}`).then(res => setChannel(res.data));
  }, [id]);

  if (!channel) return <div>Loading...</div>;

  return (
    <div>
      <h2>{channel.channelName}</h2>
      <p>{channel.description}</p>
      <p>Subscribers: {channel.subscribers}</p>
      <div className='grid'>
        {channel.videos.map(vid => <div key={vid}>{vid}</div>)}
      </div>
    </div>
  );
}

export default Channel;
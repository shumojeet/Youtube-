import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function VideoPlayer() {
  const { id } = useParams();
  const [video, setVideo] = useState(null);

  useEffect(() => {
    axios.get(`/api/videos/${id}`).then(res => setVideo(res.data));
  }, [id]);

  if (!video) return <div>Loading...</div>;

  return (
    <div>
      <video controls src={video.videoUrl} width='600' />
      <h2>{video.title}</h2>
      <p>{video.description}</p>
      <p>Channel: {video.channelId}</p>
    </div>
  );
}

export default VideoPlayer;